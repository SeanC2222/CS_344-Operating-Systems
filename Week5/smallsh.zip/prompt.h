#ifndef PROMPT_H
#define PROMPT_H

void promptUser();
void getUserInput(char*);
int checkBackground();

#endif
