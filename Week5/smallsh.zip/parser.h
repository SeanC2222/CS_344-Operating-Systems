#ifndef PARSER_H
#define PARSER_H

#include "tokenizedcommand.h"

void parseInput(char*, struct tokenizedCommand*);

#endif
