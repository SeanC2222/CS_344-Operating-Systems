Files present
   definitions.h
   executer.c
   executer.h
   main.c
   makefile
   parser.c
   parser.h
   prompt.c
   prompt.h
   readme.txt
   tokenizedcommand.c
   tokenizedcommand.h

To compile:
   1) Use the makefile, the default will compile everything properly.
      Example (bash$ indicates current shell):
   
      bash$ make 

   2) The makefile should work, else try
      
      bash$ gcc *.c *.h -o smallsh


